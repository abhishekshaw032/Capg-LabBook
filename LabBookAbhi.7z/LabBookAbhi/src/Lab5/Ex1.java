package Lab5;



class AgeNotSupportException extends Exception
{
	 AgeNotSupportException(String message)
	 {
		 System.out.println("Your age is: "+message);
	 }
}
public class Ex1 {
	int age=14;
	public void myData() throws AgeNotSupportException
	{
		if(age<15)
			throw new AgeNotSupportException("Not Eligible");
		else
			System.out.println("Eligible");
	}

	public static void main(String[] args) {
		try {
			Ex1 ude= new Ex1();
			ude.myData();
		}
		catch(Exception ee)
		{
			System.out.println("I can handle: " +ee);
		}

	}

}