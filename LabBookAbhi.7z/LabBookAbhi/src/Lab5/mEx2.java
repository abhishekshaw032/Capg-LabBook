package Lab5;

class NameNotSupportException extends Exception
{
	 NameNotSupportException(String message)
	 {
		 System.out.println("Name of Employee: "+message);
	 }
}
public class mEx2 {
	String fname="Abhi", lname="S", fullname=fname+ " "+lname;
	public void myData() throws NameNotSupportException
	{
		if(fname.length()>0 && lname.length()>0 )
			throw new NameNotSupportException(fullname);
			}

	public static void main(String[] args) {
		try {
			mEx2 ude= new mEx2();
			ude.myData();
		}
		catch(Exception ee)
		{
			System.out.println("Name Cannot be Null\n" +ee);
		}

	}

}