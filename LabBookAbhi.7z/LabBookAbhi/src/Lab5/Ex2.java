package Lab5;


public class Ex2 {
String fname="Abhi", lname="s";
	
	public void show()
	{
	try {
		System.out.println("Full Name of Employee: "+fname  +lname);
		System.out.println(fname.length());
        System.out.println(lname.length());
	}
	catch(NullPointerException ee)
	{
		System.out.println("I can handle exception: "+ee);
	}
	}

	public static void main(String[] args) {
		
		Ex2 ex1 = new Ex2();
		ex1.show();

	}
}
