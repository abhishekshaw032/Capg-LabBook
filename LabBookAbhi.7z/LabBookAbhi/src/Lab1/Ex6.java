package Lab1;
import java.util.Scanner;
public class Ex6 {
	static int calculateDifference(int n){
		  
		int l, k, m;
		    
		    l = (n * (n + 1) * (2 * n + 1)) / 6;
		    k = (n * (n + 1)) / 2;
		    k = k * k;
		    m =k-l;
		    return m;
		}
		
		public static void main(String s[])
		{

			System.out.println("Enter the value:");
			Scanner sc =new Scanner(System.in);
			int n=sc.nextInt();
	
			
		    System.out.println(calculateDifference(n));     
		      
		}

}
